package banking;

/**
 * Abstract bank account.
 */
public abstract class Account {
    private Long accountNumber;
    private int pin;
    private double balance;
    private AccountHolder accountHolder;

    public Account(Long accountNumber, AccountHolder accountHolder, int pin, double startingBalance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.pin = pin;
        this.balance = startingBalance;
    }

    public Long getAccountNumber() {
        return accountNumber;
    }

    public AccountHolder getAccountHolder() {
        return accountHolder;
    }

    public double getBalance() {
        return balance;
    }

    public boolean validatePin(int inputPin) {
        return this.pin == inputPin;
    }

    public void creditAccount(double amount) {
        if (amount > 0) {
            this.balance += amount;
        } else {
            throw new IllegalArgumentException("Amount to credit should be positive");
        }
    }

    public boolean debitAccount(double amount) {
        if (amount > 0 && this.balance >= amount) {
            this.balance -= amount;
            return true;
        }
        return false;
    }
}
