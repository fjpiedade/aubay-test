package banking;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The Bank implementation.
 */
public class Bank implements BankInterface {
    private LinkedHashMap<Long, Account> accounts;
    private long nextAccountNumber;

    public Bank() {
        accounts = new LinkedHashMap<>();
        nextAccountNumber = 1000000000L; // Starting account number
    }

    private Account getAccount(Long accountNumber) {
        return accounts.get(accountNumber);
    }

    public Long openCommercialAccount(Company company, int pin, double startingDeposit) {
        Long accountNumber = nextAccountNumber++;
        CommercialAccount account = new CommercialAccount(accountNumber, company, pin, startingDeposit);
        accounts.put(accountNumber, account);
        return accountNumber;
    }

    public Long openConsumerAccount(Person person, int pin, double startingDeposit) {
        Long accountNumber = nextAccountNumber++;
        ConsumerAccount account = new ConsumerAccount(accountNumber, person, pin, startingDeposit);
        accounts.put(accountNumber, account);
        return accountNumber;
    }

    @Override
    public double getBalance(Long accountNumber) {
        Account account = getAccount(accountNumber);
        return (account != null) ? account.getBalance() : -1.0;
    }

    public void credit(Long accountNumber, double amount) {
        Account account = getAccount(accountNumber);
        if (account != null) {
            account.creditAccount(amount);
        } else {
            throw new IllegalArgumentException("Account number not found");
        }
    }

    public boolean debit(Long accountNumber, double amount) {
        Account account = getAccount(accountNumber);
        if (account != null) {
            return account.debitAccount(amount);
        }
        throw new IllegalArgumentException("Account number not found");
    }

    public boolean authenticateUser(Long accountNumber, int pin) {
        Account account = getAccount(accountNumber);
        if (account != null) {
            return account.validatePin(pin);
        }
        return false;
    }

    public void addAuthorizedUser(Long accountNumber, Person authorizedPerson) {
        Account account = getAccount(accountNumber);
        if (account != null) {
            if (account instanceof CommercialAccount) {
                ((CommercialAccount) account).addAuthorizedUser(authorizedPerson);
            } else {
                throw new IllegalArgumentException("Only commercial accounts can have authorized users");
            }
        } else {
            throw new IllegalArgumentException("Account number not found");
        }
    }

    public boolean checkAuthorizedUser(Long accountNumber, Person authorizedPerson) {
        Account account = getAccount(accountNumber);
        if (account != null) {
            if (account instanceof CommercialAccount) {
                return ((CommercialAccount) account).isAuthorizedUser(authorizedPerson);
            } else {
                return false;
            }
        }
        return false;
    }

    public Map<String, Double> getAverageBalanceReport() {
        double commercialTotal = 0;
        int commercialCount = 0;
        double consumerTotal = 0;
        int consumerCount = 0;

        for (Account account : accounts.values()) {
            if (account instanceof CommercialAccount) {
                commercialTotal += account.getBalance();
                commercialCount++;
            } else if (account instanceof ConsumerAccount) {
                consumerTotal += account.getBalance();
                consumerCount++;
            }
        }

        Map<String, Double> report = new LinkedHashMap<>();
        report.put(ConsumerAccount.class.getSimpleName(), consumerCount == 0 ? 0 : consumerTotal / consumerCount);
        report.put(CommercialAccount.class.getSimpleName(), commercialCount == 0 ? 0 : commercialTotal / commercialCount);
        return report;
    }
}
