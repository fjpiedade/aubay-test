package banking;

import java.util.ArrayList;
import java.util.List;


/**
 * Account implementation for commercial (business) customers.
 * The account's holder is a {@link Company}.
 */
public class CommercialAccount extends Account{
    private final List<Person> authorizedUsers;

    public CommercialAccount(Long accountNumber, Company company, int pin, double startingDeposit) {
        super(accountNumber, company, pin, startingDeposit);
        this.authorizedUsers = new ArrayList<>();
    }

    /**
     * Add person to list of authorized users.
     *
     * @param person The authorized user to be added to the account.
     */
    protected void addAuthorizedUser(Person person) {
        if (person != null && !authorizedUsers.contains(person)) {
            authorizedUsers.add(person);
        }
    }

    /**
     * Verify if the person is part of the list of authorized users for this account.
     *
     * @param person
     * @return <code>true</code> if person matches an authorized user in {@link #authorizedUsers}; <code>false</code> otherwise.
     */
    public boolean isAuthorizedUser(Person person) {
        // TODO: complete the method
        return authorizedUsers.contains(person);
    }
}
