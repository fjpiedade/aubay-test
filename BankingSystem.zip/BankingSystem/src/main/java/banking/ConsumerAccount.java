package banking;

/**
 * Account implementation for consumer (domestic) customers.
 * The account's holder is a {@link Person}.
 */
public class ConsumerAccount extends Account{

    private Person person;

    public ConsumerAccount(Long accountNumber, Person person, int pin, double startingBalance) {
        super(accountNumber, person, pin, startingBalance);
        this.person = person;
    }

    public Person getPerson() {
        return person;
    }
}
